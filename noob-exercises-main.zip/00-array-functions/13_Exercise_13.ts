/*## Exercise #13

Turn an array of numbers into a total of all the numbers.

*/


function total(arr) {
  // your code here
}

console.log(total([1, 2, 3])); // 6



