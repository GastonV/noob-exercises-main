/*## Exercise #16

Given an array of numbers, return a new array that only includes the even numbers.

*/


function evensOnly(arr) {
  // your code here
}
// test
console.log(evensOnly([3, 6, 8, 2])); /// [6, 8, 2]



