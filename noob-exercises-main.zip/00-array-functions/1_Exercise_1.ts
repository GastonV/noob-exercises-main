/*## Exercise #1

Input: Array of elements

*/


["h", "o", "l", "a"];



Output: String with comma delimited elements of the array in the same order.

*/


"h,o,l,a";




