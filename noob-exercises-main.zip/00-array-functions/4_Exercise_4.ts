/*## Exercise #4

Capitalize each of an array of names.

*/


function capitalizeNames(arr) {
  // your code here
}

console.log(capitalizeNames(["john", "JACOB", "jinGleHeimer", "schmidt"])); // ["John", "Jacob", "Jingleheimer", "Schmidt"]



