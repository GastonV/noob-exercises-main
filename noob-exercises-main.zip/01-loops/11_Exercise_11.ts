/*## Exercise #11

_Example:_



> Enter the number:
> 5
A
B B
C C C
D D D D
E E E E E



*/