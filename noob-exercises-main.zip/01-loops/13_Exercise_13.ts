/*## Exercise #13

_Examples:_



> Enter the number:
> 2
**
||





> Enter the number:
> 5
--*--
-***-
*****
|***|
|***|





> Enter the number:
> 8
---**---
--****--
-******-
********
|******|
|******|
|******|
|******|



*/