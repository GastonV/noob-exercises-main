/*## Exercise #14

_Examples:_



> Enter the number:
> 1
*





> Enter the number:
> 4
-**-
*--*
-**-





> Enter the number:
> 9
----*----
---*-*---
--*---*--
-*-----*-
*-------*
-*-----*-
--*---*--
---*-*---
----*----



*/