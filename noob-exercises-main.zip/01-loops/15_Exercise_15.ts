/*## Exercise #15

_Examples:_



> Enter the number:
> 5
> Select direction: (right/left)
> right
> Is it empty? (Y/n)
> n
    *****
   *****
  *****
 *****
*****





> Enter the number:
> 5
> Select direction: (right/left)
> left
> Is it empty? (Y/n)
> n
*****
 *****
  *****
   *****
    *****





> Enter the number:
> 5
> Select direction: (right/left)
> right
> Is it empty? (Y/n)
> Y
    *****
   *   *
  *   *
 *   *
*****





> Enter the number:
> 5
> Select direction: (right/left)
> left
> Is it empty? (Y/n)
> Y
*****
 *   *
  *   *
   *   *
    *****



*/