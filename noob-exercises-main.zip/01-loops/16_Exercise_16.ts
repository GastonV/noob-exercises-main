/*## Exercise #16

_Examples:_



> Enter the number:
> 3
/^\/^\
|    |
\_/\_/





> Enter the number:
> 5
/^^\__/^^\
|        |
|        |
|   __   |
\__/  \__/





> Enter the number:
> 8
/^^^^\____/^^^^\
|              |
|              |
|              |
|              |
|              |
|     ____     |
\____/    \____/



*/