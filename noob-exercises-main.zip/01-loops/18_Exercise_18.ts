/*## Exercise #18

_Examples:_



> Enter the number:
> 8
   1
   2    1
   4    2    1
   8    4    2    1
  16    8    4    2    1
  32   16    8    4    2    1
  64   32   16    8    4    2    1
 128   64   32   16    8    4    2    1



*/