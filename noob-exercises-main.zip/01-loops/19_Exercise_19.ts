/*## Exercise #19

_Examples:_



> Enter the number:
> 5
5 4 3 2 1 1 2 3 4 5

5 4 3 2     2 3 4 5

5 4 3         3 4 5

5 4             4 5

5                 5



*/