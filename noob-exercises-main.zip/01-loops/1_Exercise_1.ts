/*## Exercise #1

Print the rectange with a size of `n` x `n` where `n` is a number provided by user.

_Example:_



> Enter the number:
> 10
**********
**********
**********
**********
**********
**********
**********
**********
**********
**********



*/