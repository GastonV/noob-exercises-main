/*## Exercise #20

_Examples:_



> Enter the number:
> 4
1 * 2 * 3 * 4

1 * 2 * 3

1 * 2

1



*/