/*## Exercise #22

_Examples:_



> Enter the number:
> 5
> Select direction: (R/L)
> R
*****
  ****
    ***
      **
        *
      **
    ***
  ****
*****





> Enter the number:
> 5
> Select direction: (R/L)
> L
    *****
   ****
  ***
 **
*
 **
  ***
   ****
    *****



*/