/*## Exercise #27

_Example:_



> Enter the number:
> 7
# # # # # # #
 # # # # # # #
# # # # # # #
 # # # # # # #
# # # # # # #
 # # # # # # #
# # # # # # #



*/