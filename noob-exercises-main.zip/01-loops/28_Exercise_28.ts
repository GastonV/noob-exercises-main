/*## Exercise #28

_Examples:_



> Enter the size:
> 8
> Select the type: (a/b/c/d)
> a
#
# #
# # #
# # # #
# # # # #
# # # # # #
# # # # # # #
# # # # # # # #





> Enter the size:
> 8
> Select the type: (a/b/c/d)
> b
# # # # # # # #
# # # # # # #
# # # # # #
# # # # #
# # # #
# # #
# #
#





> Enter the size:
> 8
> Select the type: (a/b/c/d)
> c
# # # # # # # #
  # # # # # # #
    # # # # # #
      # # # # #
        # # # #
          # # #
            # #
              #





> Enter the size:
> 8
> Select the type: (a/b/c/d)
> d
              #
            # #
          # # #
        # # # #
      # # # # #
    # # # # # #
  # # # # # # #
# # # # # # # #



*/