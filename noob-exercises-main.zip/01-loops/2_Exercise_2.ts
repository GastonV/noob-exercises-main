/*## Exercise #2

As in `Exercise #1` print a rectangle, but this time draw stars separated by a space.

_Example:_



> Enter the number:
> 3
* * *
* * *
* * *



*/