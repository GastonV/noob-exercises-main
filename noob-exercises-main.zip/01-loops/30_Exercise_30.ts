/*## Exercise #30

_Examples:_



> Enter the size:
> 8
> Select the type: (a/b/c/d)
> a
1
1 2
1 2 3
1 2 3 4
1 2 3 4 5
1 2 3 4 5 6
1 2 3 4 5 6 7
1 2 3 4 5 6 7 8





> Enter the size:
> 8
> Select the type: (a/b/c/d)
> b
1 2 3 4 5 6 7 8
  1 2 3 4 5 6 7
    1 2 3 4 5 6
      1 2 3 4 5
        1 2 3 4
          1 2 3
            1 2
              1





> Enter the size:
> 8
> Select the type: (a/b/c/d)
> c
              1
            1 2
          1 2 3
        1 2 3 4
      1 2 3 4 5
    1 2 3 4 5 6
  1 2 3 4 5 6 7
1 2 3 4 5 6 7 8





> Enter the size:
> 8
> Select the type: (a/b/c/d)
> d
8 7 6 5 4 3 2 1
7 6 5 4 3 2 1
6 5 4 3 2 1
5 4 3 2 1
4 3 2 1
3 2 1
2 1
1



