/*## Exercise #3

_Example:_



> Enter the number:
> 5
*****
*   *
*   *
*   *
*****



*/