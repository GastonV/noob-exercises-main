/*## Exercise #4

_Example:_



> Enter the number:
> 5
> Select the character:
> $
$
$ $
$ $ $
$ $ $ $
$ $ $ $ $



*/