/*## Exercise #5

_Example:_



> Enter the number:
> 5
*.....*
.*...*.
..*.*..
...*...
..*.*..
.*...*.
*.....*



*/