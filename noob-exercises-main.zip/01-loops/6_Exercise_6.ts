/*## Exercise #6

_Example:_



> Enter the number:
> 5
******
.*****
..****
...***
....**
.....*



*/