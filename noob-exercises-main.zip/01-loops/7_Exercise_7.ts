/*## Exercise #7

_Example:_



> Enter the number:
> 4
+ - - +
| - - |
| - - |
+ - - +



*/