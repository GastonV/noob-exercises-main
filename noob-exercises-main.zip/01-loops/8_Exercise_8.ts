/*## Exercise #8

_Examples:_



> Enter the number:
> 1
*





> Enter the number:
> 4
   *
  * *
 * * *
* * * *
 * * *
  * *
   *



*/